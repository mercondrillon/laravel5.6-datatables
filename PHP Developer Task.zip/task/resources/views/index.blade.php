
<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.16/css/dataTables.bootstrap.min.css">
<div class="container">
<div class="row"> 
    <h2> PHP Developer Task</h2>
</div> 
  <div class="row">
        <table id="users-table" class="table table-striped table-bordered">
        <thead>
          <tr>
            <th>Name</th>
            <th>Price</th>
            <th>Bedrooms</th>
            <th>Storeys</th>
            <th>Garages</th>
          </tr>
        </thead>
    </table>    
  </div>
</div>



<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.16/js/dataTables.bootstrap.min.js"></script>
<script type="text/javascript">
      $(function() {

        $('#users-table').DataTable({
            "processing": true,
            "serverSide": true,
            "ajax": 'http://localhost:8000/index/getdata',
            "columns":[
                {"data": "Name"},
                {"data": "Price"},
                {"data": "Bedrooms"},
                {"data": "Storeys"},
                {"data": "Garages"}

            ]
          });
      });
</script>