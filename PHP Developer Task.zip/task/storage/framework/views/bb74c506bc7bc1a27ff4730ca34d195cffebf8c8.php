<html>
    <head>
        <title>App Name - <?php echo $__env->yieldContent('title'); ?></title>
        <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
        <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
        welcome
    </head>
    <body>

    </body>
</html>