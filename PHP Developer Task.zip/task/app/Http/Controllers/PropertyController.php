<?php

namespace App\Http\Controllers;


use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use DataTables;
use App\Property;

class PropertyController extends Controller
{
    //
	/**
	public function index()
    {
        $property=Property::all();
        return view('index',compact('property'));
    }

	

	function create(){

		return view('create');
	}



	function store(Request $request)
	{

		$data = new Property();
		$data->name=$request->get('name');
		$data->Price=$request->get('price');
		$data->Bedrooms=$request->get('bedrooms');
		$data->Storeys=$request->get('storeys');
		$data->Garages=$request->get('garages');
		$data->save();


			return redirect()->back()->with('success', 'Information has been added');	


	}
	**/

	public function datatable()
    {
        return view('index');
    }

    public function getPosts()
    {
                return DataTables::eloquent(Property::query())->make(true);

    }


}
